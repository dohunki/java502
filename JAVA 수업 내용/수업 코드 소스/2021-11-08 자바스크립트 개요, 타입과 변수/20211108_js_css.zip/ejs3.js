document.write("ejs3.js");
document.write("<div style='color: green; font-size: 16px;'>외부 자바스크립트 파일</div>");