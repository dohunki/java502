document.write("ejs2.js");
document.write("<div style='color: blue; font-size: 20px;'>외부 자바스크립트 파일</div>");