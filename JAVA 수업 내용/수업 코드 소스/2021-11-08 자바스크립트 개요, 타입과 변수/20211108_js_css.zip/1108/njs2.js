document.write("njs2.js");
document.write("<div style='color: blue; font-size: 20px;'>외부 자바스크립트 파일</div>");
document.write("<script src='./1108/njs3.js'></script>");