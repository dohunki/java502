var btn = document.querySelector("#btn");
btn.addEventListener("click", function() {
    alert("외부파일 js01-01.js 파일을 로드하여 사용");
});