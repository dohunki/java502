document.write("njs1.js");
document.write("<div style='color: red; font-size: 24px;'>외부 자바스크립트 파일</div>");
document.write("<script src='./1108/njs2.js'></script>");